class TedxTalk {
  final String id;
  final String title;
  final String speaker;
  final String description;
  final String topic;
  final String duration;
  final String thumbnailUrl;
  final String videoUrl;
  final String youtubeId;
  final int year;
  final String event;
  final List<String> tags;

  TedxTalk({
    required this.id,
    required this.title,
    required this.speaker,
    required this.description,
    required this.topic,
    required this.duration,
    required this.thumbnailUrl,
    required this.videoUrl,
    required this.youtubeId,
    required this.year,
    required this.event,
    required this.tags,
  });

  factory TedxTalk.fromJson(Map<String, dynamic> json) {
    return TedxTalk(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? '',
      speaker: json['speaker']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      topic: json['topic']?.toString() ?? '',
      duration: json['duration']?.toString() ?? '',
      thumbnailUrl: json['thumbnail_url']?.toString() ?? '',
      videoUrl: json['video_url']?.toString() ?? '',
      youtubeId: json['youtube_id']?.toString() ?? '',
      year: int.tryParse(json['year']?.toString() ?? '0') ?? 0,
      event: json['event']?.toString() ?? '',
      tags: List<String>.from(json['tags'] ?? []),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'speaker': speaker,
        'description': description,
        'topic': topic,
        'duration': duration,
        'thumbnail_url': thumbnailUrl,
        'video_url': videoUrl,
        'youtube_id': youtubeId,
        'year': year,
        'event': event,
        'tags': tags,
      };
}
